---
name: Wouwse Heritage Modern
colors:
  surface: '#fff8f8'
  surface-dim: '#e1d8d9'
  surface-bright: '#fff8f8'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#fbf1f2'
  surface-container: '#f5eced'
  surface-container-high: '#efe6e7'
  surface-container-highest: '#e9e0e1'
  on-surface: '#1e1b1c'
  on-surface-variant: '#3e4944'
  inverse-surface: '#342f30'
  inverse-on-surface: '#f8efef'
  outline: '#6e7a73'
  outline-variant: '#bec9c2'
  surface-tint: '#006c50'
  primary: '#00543e'
  on-primary: '#ffffff'
  primary-container: '#006f53'
  on-primary-container: '#96efcb'
  inverse-primary: '#80d7b5'
  secondary: '#3f6908'
  on-secondary: '#ffffff'
  secondary-container: '#bbef83'
  on-secondary-container: '#436e0e'
  tertiary: '#414b50'
  on-tertiary: '#ffffff'
  tertiary-container: '#596368'
  on-tertiary-container: '#d5dfe5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#9cf4d0'
  primary-fixed-dim: '#80d7b5'
  on-primary-fixed: '#002116'
  on-primary-fixed-variant: '#00513c'
  secondary-fixed: '#bef285'
  secondary-fixed-dim: '#a3d56c'
  on-secondary-fixed: '#0f2000'
  on-secondary-fixed-variant: '#2d5000'
  tertiary-fixed: '#dae4ea'
  tertiary-fixed-dim: '#bec8ce'
  on-tertiary-fixed: '#131d21'
  on-tertiary-fixed-variant: '#3f484d'
  background: '#fff8f8'
  on-background: '#1e1b1c'
  surface-variant: '#e9e0e1'
typography:
  headline-xl:
    fontFamily: Newsreader
    fontSize: 48px
    fontWeight: '600'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Newsreader
    fontSize: 36px
    fontWeight: '500'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Newsreader
    fontSize: 28px
    fontWeight: '500'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.6'
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  label-sm:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.2'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  container-max: 1280px
  gutter: 24px
  margin-edge: 32px
  stack-sm: 16px
  stack-md: 32px
  stack-lg: 64px
  section-padding: 120px
---

## Brand & Style

The brand personality is rooted in the quiet confidence of a premier historic golf estate. It aims to evoke an emotional response of serenity, exclusivity, and athletic prestige. The visual narrative balances the "Heritage" aspect—respecting the deep traditions of the sport and the club’s established history—with "Modernity"—providing a frictionless, clean, and professional digital interface.

The design style is **Corporate / Modern with Minimalist influences**. It prioritizes extreme legibility and structured hierarchy to cater to a discerning, high-end clientele. By utilizing heavy whitespace (macro-spacing) and a restrained, natural color palette, the interface mimics the open, expansive feel of the Wouwse Plantage fairways. Subtle depth is used not for decoration, but to clarify the information architecture, ensuring that the user's journey is as smooth as a well-kept putting green.

## Colors

The color palette is derived directly from the natural environment of the golf course. 
- **Primary Green (#006f53):** A deep, forest-inspired green used for core branding, primary buttons, and navigation anchors. It represents the stability and prestige of the club.
- **Secondary Lime (#9bcd65):** A vibrant, grass-inspired green used sparingly for accents, success states, and subtle highlights to inject energy and modern vitality into the layout.
- **Elegant Charcoal (#231f20):** Used for primary typography and structural elements. It provides better readability and a softer, more sophisticated touch than pure black.
- **Heritage Silver (#a7b1b7):** A neutral gray used for secondary information, borders, and disabled states, echoing the metallic tones of golf equipment and the club's logo.
- **Crisp Surface (#F9FBF9):** A slightly tinted off-white used for backgrounds to reduce eye strain and provide a "paper-like" premium feel compared to sterile #FFFFFF.

## Typography

This typography system establishes a "Traditional-Modern" bridge. 

**Headlines** utilize **Newsreader**, a serif font that communicates authority, literary elegance, and a classic club atmosphere. It is best used for storytelling, section titles, and welcoming messages.

**Body and Interface elements** use **Work Sans**. This choice ensures high functional legibility across various screen sizes. Its neutral and reliable character balances the more expressive serif headlines. 

The use of **Label-sm** in uppercase with increased letter spacing is intended for category tags, overlines, and small navigational markers to create a rhythmic, structured appearance.

## Layout & Spacing

The design system employs a **Fixed Grid** philosophy for desktop screens to maintain a curated, editorial feel, while transitioning to a fluid model for mobile devices. 

A 12-column grid is the standard for content organization, with generous 24px gutters. The primary differentiator in this layout is the use of **extreme vertical whitespace**. Section padding is intentionally large (120px+) to allow high-resolution imagery of the golf course fairways to "breathe" and serve as a visual palette cleanser between information-dense areas.

Internal component spacing follows an 8px base unit, ensuring consistent alignment of text and interactive elements.

## Elevation & Depth

To maintain a clean and sophisticated aesthetic, elevation is handled through **Low-contrast outlines** and **Ambient shadows**. 

- **Surface Layers:** The background is the primary surface. Cards and containers use a pure white surface to lift slightly from the off-white background.
- **Shadow Profile:** Shadows are extremely diffused (high blur radius, low opacity) and slightly tinted with the Primary Green color to prevent them from looking "dirty" or "gray." This creates a soft glow rather than a hard drop-shadow.
- **Depth Cues:** Depth is used primarily to indicate interactivity (e.g., a card lifting slightly on hover) or to separate global navigation from the scrolling content below. Borders are used minimally, typically 1px in the Heritage Silver color to define boundaries without adding visual clutter.

## Shapes

The shape language is **Soft (0.25rem)**. While a sharp edge feels too aggressive and a pill-shape feels too casual, a subtle rounding of corners strikes a balance of professional precision and modern approachability.

This slight curvature is applied to buttons, input fields, and card containers. The goal is for the UI to feel "tailored"—reflecting the craftsmanship of the course and the high-end apparel often associated with the sport.

## Components

### Buttons
Primary buttons use the Primary Green background with White text, employing a subtle 1px border of the same green for crispness. Hover states should see a slight darkening of the green or the addition of a soft ambient shadow. Secondary buttons should use a ghost style: Primary Green text and border with a transparent background.

### Cards
Cards are the primary vessel for course updates and membership information. They feature a 1px Heritage Silver border, ample internal padding (32px), and use Newsreader for titles. Images within cards should have a slight 4px top-corner radius to match the container.

### Input Fields
Inputs are minimalist, featuring a bottom-border only or a very light 1px border on all sides. Focused states should be indicated by a Primary Green border and a soft green outer glow. Labels are always Work Sans (Label-sm).

### Chips & Tags
Used for indicating course status (e.g., "Open," "Tournament") or membership levels. These use a light tint of the Secondary Lime or Primary Green with dark text to remain legible but subordinate to the main content.

### Imagery & Logo Style
Images should prioritize natural light and high-saturation greens. The logo, based on the SVG provided, should be used prominently in the navigation bar, typically centered or left-aligned with sufficient clear space. Incorporate the diamond/rhombus shape from the logo as a decorative element or bullet point style to reinforce brand recognition.